-- Switch Unity premake module
local platform = {}

local function ConvertDependenciesToPostBuildStep(dependencies)
	local addLogs = true

	local newLine = "\r\n"
	local saveRootDirectory = "pushd ."
	local returnToRootDirectory = "popd"
	local ar = "$(NINTENDO_SDK_ROOT)/Compilers/NX/nx/aarch64/bin/aarch64-nintendo-nx-elf-ar.exe"

	local output = ""

	if addLogs then
		output = output .. "echo This script is generated within the premake5.lua file." .. newLine
	end

	for i,v in ipairs(dependencies) do
		local tempDirectory = "$(IntDir)" .. v

		local currentLibPath = wwiseSDKEnv .. "/$(Platform)/$(Configuration)/lib/lib" .. v .. ".a"

		local createDirectory = 
			"mkdir " .. tempDirectory .. newLine ..
			"cd " .. tempDirectory

		local extract = ar .. " x \"" .. currentLibPath .. "\""

		local addObjectsToArchive = ar .. " r $(TargetPath) " .. tempDirectory .. "/*.o"

		local removeDirectory = "rmdir /s /q " .. tempDirectory

		if addLogs then
			extract = "echo Extracting objects from library \"" .. currentLibPath .. "\" into temporary directory \"" .. tempDirectory .. "\"." .. newLine .. extract
			addObjectsToArchive = "echo Adding objects to library \"$(TargetFileName)\"." .. newLine .. addObjectsToArchive
		end

		output = output
			.. saveRootDirectory .. newLine
			.. createDirectory .. newLine
			.. extract .. newLine
			.. returnToRootDirectory .. newLine
			.. addObjectsToArchive .. newLine
			.. removeDirectory .. newLine
	end

	return output
end

function platform.setupTargetAndLibDir(baseTargetDir)
    targetdir(baseTargetDir .. "Switch/%{cfg.platform}/%{cfg.buildcfg}")
    libdirs(wwiseSDKEnv .. "/%{cfg.platform}/%{cfg.buildcfg}/lib")
end

function platform.platformSpecificConfiguration()
	kind "StaticLib"
	targetname "AkSoundEngineWrapper"

	local function SwitchAddPostBuildCommand(useCommunication)
		local depends = SoundEngineInternals("", useCommunication)
		depends[#depends+1] = "AkOpusNXDecoder"

		postbuildcommands(ConvertDependenciesToPostBuildStep(depends))
	end

	filter "Debug* or Profile*"
		SwitchAddPostBuildCommand(true)
	filter "Release*"
		SwitchAddPostBuildCommand(false)
end

return platform