# Switch Wwise Unity Build module
import BuildUtil
import BuildWwiseUnityIntegration
import GenerateApiBinding
import os
from os import path
from BuildWwiseUnityIntegration import MultiArchBuilder
from GenerateApiBinding import SwigCommand
from PrepareSwigInput import SwigPlatformHandler, SwigApiHeaderBlobber, PlatformStructProfile

class SwitchBuilder(MultiArchBuilder):
	def __init__(self, platformName, arches, configs, generateSwig, generatePremake):
		MultiArchBuilder.__init__(self, platformName, arches, configs, generateSwig, generatePremake)
		
		self._FindMSBuildPath()

		pathMan = BuildUtil.PathManager(self.platformName)
		self.solution = path.join(pathMan.Paths['Src_Platform'], '{}Switch.sln'.format(pathMan.ProductName))
		self.FixedArch = 'Switch'
		
	def _CreateCommands(self, arch=None, config='Profile'):
		cmds = []

		for t in self.tasks:
			cmd = ['{}'.format(self.compiler), '{}'.format(self.solution), '/t:{}'.format(t), '/p:Configuration={}'.format(config), '/p:Platform={}'.format(arch)]
			cmds.append(cmd)

		return cmds

class SwitchSwigCommand(SwigCommand):
	def __init__(self, pathMan):
		SwigCommand.__init__(self, pathMan)

		self.platformDefines += ['-DAK_NX']
		self.dllName = ['-dllimport', '__Internal']
		self.Includes = \
		[
			'-I%s' % (os.path.join(os.environ['NINTENDO_SDK_ROOT'], 'Include')),
			'-I%s' % (os.path.join(os.environ['NINTENDO_SDK_ROOT'], 'Compilers', 'NX', 'nx', 'aarch64', 'include', 'aarch64-nintendo-nx-elf')),
			'-I%s' % (os.path.join(os.environ['NINTENDO_SDK_ROOT'], 'Compilers', 'NX', 'nx', 'aarch64', 'include', 'c++', 'v1')),
			'-I%s' % (os.path.join(os.environ['NINTENDO_SDK_ROOT'], 'Compilers', 'NX', 'nx', 'aarch64', 'lib', 'clang', '1.10.6', 'include')),
			'-I%s' % (os.path.join(os.environ['NINTENDO_SDK_ROOT'], 'Common', 'Configs', 'Targets', 'NX-NXFP2-a64', 'Include'))
		]

class SwigApiHeaderBlobberSwitch(SwigApiHeaderBlobber):
	def __init__(self, pathMan):
		SwigApiHeaderBlobber.__init__(self, pathMan)

		self.inputHeaders.append(path.normpath(path.join(self.SdkIncludeDir, 'AK/SoundEngine/Platforms/NX/AkNXSoundEngine.h')))

class SwigPlatformHandlerSwitch(SwigPlatformHandler):
	def __init__(self, pathMan):
		SwigPlatformHandler.__init__(self, pathMan)

		ThreadPropertyHeader = 'AK/Tools/NX/AkPlatformFuncs.h'
		self.PlatformStructProfiles += \
		[
			PlatformStructProfile(self.pathMan, ThreadPropertyHeader, SwigPlatformHandler.ThreadPropertiesRegEx)
		]

		self.ioFileSources = \
		[
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], 'SoundEngine\\NX\\stdafx.cpp'),
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], 'SoundEngine\\NX\\stdafx.h'),
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], 'SoundEngine\\NX\\AkFileHelpers.h'),
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], 'SoundEngine\\NX\\AkFileHelpers.cpp'),
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], 'SoundEngine\\NX\\AkDefaultIOHookBlocking.cpp'),
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], 'SoundEngine\\NX\\AkDefaultIOHookBlocking.h'),
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], 'SoundEngine\\NX\\AkFilePackageLowLevelIOBlocking.h')			
		]

def Init(argv=None):
	BuildUtil.BankPlatforms['Switch'] = 'Switch'
	BuildUtil.SupportedArches['Switch'] = ['NX64']
	BuildUtil.PremakeParameters['Switch'] = { 'os': 'nx', 'generator': 'vs2017' }
	BuildUtil.PlatformSwitches['Switch'] = '#if UNITY_SWITCH && !UNITY_EDITOR'
	BuildUtil.SupportedPlatforms['Windows'].append('Switch')

def CreatePlatformBuilder(platformName, arches, configs, generateSwig, generatePremake):
	return SwitchBuilder(platformName, arches, configs, generateSwig, generatePremake)

def CreateSwigCommand(pathMan, arch):
	return SwitchSwigCommand(pathMan)

def CreateSwigPlatformHandler(pathMan):
	return SwigPlatformHandlerSwitch(pathMan)

def CreateSwigApiHeaderBlobber(pathMan):
	return SwigApiHeaderBlobberSwitch(pathMan)

if __name__ == '__main__':
	pass
