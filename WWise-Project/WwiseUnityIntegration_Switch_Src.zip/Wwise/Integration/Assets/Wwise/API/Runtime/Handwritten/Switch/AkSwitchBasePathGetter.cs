﻿#if UNITY_SWITCH && !UNITY_EDITOR
public partial class AkBasePathGetter
{
	static string DefaultPlatformName = "Switch";
}
#endif